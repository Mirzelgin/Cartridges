﻿using System;
using System.Collections.ObjectModel;
using System.ComponentModel;
using System.Runtime.CompilerServices;
using System.Windows;

namespace WpfApp3.ViewModel
{
    class NewRecordVM : INotifyPropertyChanged
    {
        public ObservableCollection<Model.Locations> Locations { get; set; }
        public ObservableCollection<Model.Devices> Devices { get; set; }
        public ObservableCollection<Model.Cartridges> Cartridges { get; set; }
        public ObservableCollection<Model.DeviceAssociation> DeviceAssociation { get; set; }

        private Model.MainLog newRecord;
        public Model.MainLog NewRecord
        {
            get { return newRecord; }
            set
            {
                newRecord = value;
                OnPropertyChanged();
            }
        }

        private RelayCommand update;
        public RelayCommand Update { get { return update ?? (update = new RelayCommand(obj => UpdateData())); } }
        public void UpdateData()
        {
            try
            {
                using (Model.ModelDB db = new Model.ModelDB())
                {
                    Cartridges = new ObservableCollection<Model.Cartridges>(db.Cartridges);
                    Devices = new ObservableCollection<Model.Devices>(db.Devices);
                    Locations = new ObservableCollection<Model.Locations>(db.Locations);
                    DeviceAssociation = new ObservableCollection<Model.DeviceAssociation>(db.DeviceAssociation);
                }
            }
            catch (Exception ex)
            {
                MessageBox.Show("Command UpdateData(), error: " + ex.Message);
                return;
            }
        }

        private RelayCommand clear;
        public RelayCommand Clear { get { return clear ?? (clear = new RelayCommand(obj => ClearNewRecord())); } }
        public void ClearNewRecord()
        {
            //Создаём объект новой записи
            NewRecord = new Model.MainLog();
            NewRecord.DateTime = DateTime.Now;
            //********************************************
        }
        


        public event PropertyChangedEventHandler PropertyChanged;
        public void OnPropertyChanged([CallerMemberName]string prop = "")
        {
            if (PropertyChanged != null)
                PropertyChanged(this, new PropertyChangedEventArgs(prop));
        }
    }
}
