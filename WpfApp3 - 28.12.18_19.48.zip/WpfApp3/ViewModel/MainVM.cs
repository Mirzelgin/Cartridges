﻿using System;
using System.Windows;
using System.Windows.Controls;
using System.ComponentModel;
using System.Runtime.CompilerServices;
using System.Collections.ObjectModel;
using System.Collections.Generic;
using System.Linq;

namespace WpfApp3.ViewModel
{
    class MainVM : INotifyPropertyChanged
    {
        private DateTime lastUpdate;
        public DateTime LastUpdate
        {
            get { return lastUpdate; }
            set
            {
                lastUpdate = value;
                OnPropertyChanged();
            }
        }

        //MainLog
        private ObservableCollection<Model.MainLog> mainLog;
        public ObservableCollection<Model.MainLog> MainLog { get { return mainLog; } set { mainLog = value; OnPropertyChanged(); } }

        private Model.MainLog selMainLog = new Model.MainLog();
        public Model.MainLog SelMainLog { get { return selMainLog; } set { selMainLog = value; OnPropertyChanged(); } }

        private Model.MainLog newRecord;
        public Model.MainLog NewRecord
        {
            get { return newRecord; }
            set
            {
                newRecord = value;
                OnPropertyChanged();
            }
        }
        
        public ObservableCollection<Model.Locations> Locations { get; set; }
        public ObservableCollection<Model.Devices> Devices { get; set; }        
        public ObservableCollection<Model.Cartridges> Cartridges { get; set; }
        public ObservableCollection<Model.DeviceAssociation> DeviceAssociation { get; set; }

        public MainVM()
        {
            ClearNewRecord();
            UpdateData();
        }

        //Загрузка данных из базы
        public void UpdateData()
        {
            try
            {
                using (Model.ModelDB db = new Model.ModelDB())
                {
                    MainLog = new ObservableCollection<Model.MainLog>(db.MainLog);
                    Cartridges = new ObservableCollection<Model.Cartridges>(db.Cartridges);
                    Devices = new ObservableCollection<Model.Devices>(db.Devices);
                    Locations = new ObservableCollection<Model.Locations>(db.Locations);
                    DeviceAssociation = new ObservableCollection<Model.DeviceAssociation>(db.DeviceAssociation);

                    //MainLog = db.MainLog.Local;
                    //Cartridges = db.Cartridges.Local;
                    //Devices = db.Devices.Local;
                    //Locations = db.Locations.Local;
                }
                LastUpdate = DateTime.Now;
            }
            catch(Exception ex)
            {
                MessageBox.Show("Command UpdateData(), error: " + ex.Message);
                return;
            }
        }
        private RelayCommand update;
        public RelayCommand Update { get { return update ?? (update = new RelayCommand(obj => UpdateData())); } }

        //Обнуление данных новой строки
        public void ClearNewRecord()
        {
            //Создаём объект новой записи и устанавливаем:
            // - текущую дату;
            NewRecord = new Model.MainLog();
            NewRecord.DateTime = DateTime.Now;
            //********************************************
        }
        private RelayCommand clear;
        public RelayCommand Clear { get { return clear ?? (clear = new RelayCommand(obj => ClearNewRecord())); } }

        //Добавление новой записи в базу
        private void AddNewRecord()
        {
            try
            {
                using (Model.ModelDB db = new Model.ModelDB())
                {
                    db.MainLog.Add(NewRecord);
                    db.SaveChanges();
                }
            }
            catch (Exception ex)
            {
                MessageBox.Show("Command Add(), error: " + ex.Message);
                return;
            }
            ClearNewRecord();
            UpdateData();
        }
        private RelayCommand addRecord;
        public RelayCommand AddRecord { get { return addRecord ?? (addRecord = new RelayCommand(obj => AddNewRecord())); } }

        private RelayCommand delete;
        public RelayCommand Delete
        {
            get
            {
                return delete ?? (delete = new RelayCommand(obj =>
                {
                    try
                    {
                        using (Model.ModelDB db = new Model.ModelDB())
                        {
                            db.Entry(SelMainLog).State = System.Data.Entity.EntityState.Deleted;
                            db.SaveChanges();
                        }
                    }
                    catch (Exception ex)
                    {
                        MessageBox.Show("Command Delete(), error: " + ex.Message);
                        return;
                    }
                    UpdateData();
                }));
            }
        }

        private RelayCommand changedLocation;
        public RelayCommand ChangedLocation
        {
            get
            {
                return changedLocation ?? (changedLocation = new RelayCommand(obj =>
                {
                    if (obj == null) return;

                    //Принимаем в качестве параметра команды выбранный 
                    //пользователем объект Locations
                    Model.Locations selectedItem = (obj as Model.Locations);
                    
                    //Выбираем ИД картриджей доступных в данной локации
                    var query = DeviceAssociation.Where(p => p.LocationId == selectedItem.Id);

                    //Сортитуем коллекцию Cartridges оставляя только записи 
                    //с Id равным LocationId из предыдущего запроса и удаляем дубли
                    Cartridges = new ObservableCollection<Model.Cartridges>(query.Select(p => p.Cartridges).Distinct());
                }));
            }
        }

        public event PropertyChangedEventHandler PropertyChanged;
        public void OnPropertyChanged([CallerMemberName]string prop = "")
        {
            if (PropertyChanged != null)
                PropertyChanged(this, new PropertyChangedEventArgs(prop));
        }
    }
}
