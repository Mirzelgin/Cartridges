﻿namespace WpfApp3.Model
{
    class Cartridge
    {
        public int Id { get; set; }
        public string Description { get; set; }
    }
}
